<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GeneralEducation extends Model
{
    protected $table = 'general_education';
}
